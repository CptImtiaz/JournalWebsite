IJCST LaTeX manuscript template
===============================
Files: main.tex (manuscript), ijcst.sty (journal style), references.bib (BibTeX references).

Overleaf: New Project > Upload Project > select this ZIP file.
Local: pdflatex main && bibtex main && pdflatex main && pdflatex main

The journal uses double-anonymous peer review: remove author names, affiliations and
acknowledgements from the version you submit for review. Submit the compiled PDF
(and later the source files on acceptance) at https://ijcst-journal.vercel.app/submit
